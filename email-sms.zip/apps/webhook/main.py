from fastapi import FastAPI
from apps.webhook.routes import twilio

app = FastAPI(title="Twilio Webhooks", version="0.1.0")
app.include_router(twilio.router, prefix="/webhooks/twilio", tags=["twilio-webhooks"])
