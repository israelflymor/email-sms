#!/usr/bin/env bash
set -euo pipefail
if [ $# -lt 1 ]; then
  echo "Usage: ./scripts/restore_postgres.sh path/to/backup.sql.gz"
  exit 1
fi

FILE="$1"
DB_NAME=${POSTGRES_DB:-messaging}
DB_USER=${POSTGRES_USER:-postgres}
DB_HOST=${DB_HOST:-localhost}
DB_PORT=${DB_PORT:-5432}

gunzip -c "$FILE" | PGPASSWORD="${POSTGRES_PASSWORD:-}" psql -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" "$DB_NAME"
echo "Restore completed."
