#!/usr/bin/env bash
set -euo pipefail
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR=${BACKUP_DIR:-./backups}
DB_NAME=${POSTGRES_DB:-messaging}
DB_USER=${POSTGRES_USER:-postgres}
DB_HOST=${DB_HOST:-localhost}
DB_PORT=${DB_PORT:-5432}

mkdir -p "$BACKUP_DIR"
FILE="$BACKUP_DIR/${DB_NAME}_${TIMESTAMP}.sql.gz"

PGPASSWORD="${POSTGRES_PASSWORD:-}" pg_dump -h "$DB_HOST" -p "$DB_PORT" -U "$DB_USER" "$DB_NAME" | gzip > "$FILE"
echo "Backup created: $FILE"
find "$BACKUP_DIR" -type f -name "*.sql.gz" -mtime +7 -delete
