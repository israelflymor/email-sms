# Phase 8 Auth Guide

## Added
- backend `/auth/login` endpoint
- signed session-token issue and verification
- bearer-token protected admin routes
- frontend login page
- frontend local session persistence
- role-aware page visibility

## Test
1. Start backend and frontend
2. Open the UI
3. Login with an API key from `.env`
4. Verify page access differs by role
5. Verify write actions fail for viewer role

## Remaining auth hardening
- replace custom token with real JWT/session auth
- store users in DB
- add password login and MFA
- add login/logout audit logs
- move signing secret to environment
