# Phase 5 notes

Added:
- Alembic migrations
- segment and campaign membership generation
- frontend actions for create/generate/approve/dispatch/retry

Still recommended:
- real auth
- HTTPS
- monitoring
- proper secrets manager
- richer segment rule builder
