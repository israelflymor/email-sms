# Phase 4 operating notes

## Roles
- admin: full control
- reviewer: approve/reject campaign reviews and paused jobs
- operator: create/pause campaigns, dispatch batches, retry jobs
- viewer: read-only dashboard

## Scheduler
- dispatches approved campaign jobs in batches
- picks up retry-ready jobs after backoff

## Next hardening
- replace API-key auth with JWT/session auth
- add real audience segmentation
- add UI actions for approve/reject/retry
- add audit logging for auth actions
