# Phase 2 hardening checklist

## Added controls
- Redis-backed global hourly and daily caps
- per-user OTP cooldown and hourly max
- per-user promotional daily and weekly caps
- per-user transactional daily and weekly caps
- duplicate-window suppression using message-body hash
- quiet-hours throttling
- Twilio webhook signature verification

## Before enabling in production
- Set `TWILIO_VALIDATE_SIGNATURE=true`
- Ensure webhook URLs match the public URL Twilio will call
- Tune caps to your real traffic model
- Add metrics and alerting for paused/throttled jobs
- Add timezone-aware quiet-hours by customer profile
