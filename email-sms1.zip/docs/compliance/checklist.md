# Operational checklist

## Before sending live US traffic
- Messaging Service created
- A2P 10DLC registration completed
- Privacy Policy and Terms URLs published
- STOP and HELP flows tested
- Consent logging tested
- Quiet hours enabled
- Risk thresholds configured
- Delivery callbacks stored
- Suppression list enforced
