# Hardening Checklist

## HTTPS
- TLS cert installed
- HTTP redirects to HTTPS
- HSTS enabled
- Twilio webhook URLs updated to HTTPS
- `TWILIO_VALIDATE_SIGNATURE=true`

## Backup strategy
- daily Postgres backups
- retention pruning enabled
- restore tested on staging
- offsite copies planned

## Monitoring
- Prometheus healthy
- Grafana healthy
- Postgres exporter healthy
- Redis exporter healthy
- alerts loaded

## Remaining security gap
- replace API-key auth with JWT/session auth
