# Phase 9 Test Plan

## 1. Local Mock SMS

Set:

```env
SMS_PROVIDER=local_mock
```

Run:

```bash
docker compose -f docker-compose.phase9.yml up --build
```

Expected:

- campaigns can dispatch
- jobs are marked `sent` or `simulated`
- no SMS is actually delivered
- policy checks still run

## 2. Mailpit Email

Open:

```text
http://localhost:8025
```

Expected:

- local email can be captured
- no real email is delivered externally

## 3. Real SMS

Do not test real SMS until:

- provider account is active
- 10DLC/toll-free/short-code compliance is completed
- sender ID is approved
- opt-in and STOP/HELP flows are verified
