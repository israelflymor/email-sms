# Phase 9 — Provider-Agnostic Messaging Layer

## Purpose

Remove hard dependency on Twilio as the only delivery mechanism.

The system can now run with:

- `local_mock` for safe development
- `mailpit` for local email capture
- `email_smtp` for SMTP delivery
- `telnyx` for real SMS
- `plivo` for real SMS
- placeholders for Vonage, AWS SMS, and SMPP gateway

## Important Principle

Removing Twilio does not remove SMS compliance obligations.

For real US SMS delivery, the project still needs a compliant provider, approved sender identity, and proper opt-in/opt-out handling.

## Providers Added

```text
packages/providers/
├── base.py
├── router.py
├── local_mock.py
├── email_smtp.py
├── mailpit.py
├── telnyx.py
├── plivo.py
├── vonage.py
├── aws_sms.py
└── smpp_gateway.py
```

## Recommended Local Development

```env
MESSAGE_PROVIDER=local_mock
SMS_PROVIDER=local_mock
EMAIL_PROVIDER=mailpit
SMTP_HOST=mailpit
SMTP_PORT=1025
```

Start:

```bash
docker compose -f docker-compose.phase9.yml up --build
```

Mailpit UI:

```text
http://localhost:8025
```

## Acceptance Criteria

- `SMS_PROVIDER=local_mock` sends simulated messages with no external provider.
- Mailpit runs locally for email testing.
- Existing compliance checks still run before provider delivery.
- Twilio-specific adapter is no longer required by core messaging flow.
