# email-sms — Phase 10A Codebase Analysis

## Analysis Basis

Source archive patched: `email-sms.zip`.

This analysis is based on direct inspection of the extracted archive, not reconstructed assumptions.

## Confirmed Present

- `apps/`
- `apps/api/`
- `apps/webhook/`
- `apps/worker/`
- `apps/scheduler/`
- `apps/admin_ui/`
- `packages/`
- `packages/providers/`
- `packages/services/provider_adapter.py`
- `packages/config/settings.py`
- `migrations/`
- `.env.example`
- `docker-compose.phase9.yml`
- `README_PHASE9.md`

## Confirmed Issues Before Patch

### 1. Admin UI API proxy missing

`apps/admin_ui/app.js` calls `/api/...`, but `apps/admin_ui/server.js` only served static files.

Impact: local login and dashboard API calls would fail unless an external proxy was configured.

### 2. Provider-neutral webhooks missing

The webhook app only registered legacy Twilio routes:

- `/webhooks/twilio/status`
- `/webhooks/twilio/inbound`

Impact: Phase 9 provider-neutral webhook paths were not available.

### 3. Admin UI production Dockerfile missing

`docker-compose.prod.yml` expects `apps/admin_ui/Dockerfile`, but the file was absent.

Impact: production compose build for `admin-ui` would fail.

### 4. Legacy Twilio database names remain

Fields such as `twilio_message_sid` remain in models.

Impact: acceptable during stabilization, but should not be mass-renamed during Phase 10A.

## Phase 10A Patch Scope

Only critical runtime blockers were patched:

- local `/api` proxy support
- provider-neutral webhook route
- webhook app route registration
- admin UI Dockerfile
- evidence reports

No architecture refactor was performed.
