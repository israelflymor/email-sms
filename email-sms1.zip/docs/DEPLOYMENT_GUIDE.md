# Deployment Guide

## Internal deployment and testing

1. Extract the ZIP:
   ```bash
   unzip twilio-us-sms-compliance-scaffold-phase6.zip
   cd twilio-us-sms-compliance-scaffold-phase6
   ```

2. Create runtime env files:
   ```bash
   cp .env.example .env
   cp .env.production.example .env.production
   ```

3. Edit `.env.production` with real values:
   - Twilio credentials
   - strong Postgres password
   - strong admin API keys
   - your domain
   - Grafana password

4. Start the internal stack:
   ```bash
   docker compose up --build
   ```

5. Run DB migrations:
   ```bash
   alembic upgrade head
   ```

6. Seed templates using the SQL in:
   `packages/templates/seed_templates.sql`

7. Start the admin UI locally if needed:
   ```bash
   cd apps/admin_ui
   npm install
   npm run dev
   ```

8. Test:
   - consent creation
   - segment creation
   - segment member generation
   - campaign creation
   - campaign member generation
   - approve + dispatch
   - paused-job review + retry
   - webhook callbacks

## Final hardening pass

1. Point DNS to the server.
2. Obtain Let's Encrypt certs for your domain.
3. Place them at:
   - `/etc/letsencrypt/live/your-domain.com/fullchain.pem`
   - `/etc/letsencrypt/live/your-domain.com/privkey.pem`
4. Start the hardened stack:
   ```bash
   docker compose -f docker-compose.prod.yml --env-file .env.production up --build -d
   ```
5. Run migrations in production:
   ```bash
   docker compose -f docker-compose.prod.yml --env-file .env.production exec api alembic upgrade head
   ```
6. Open:
   - app: `https://your-domain.com`
   - Grafana: `http://your-server:3000`
   - Prometheus: `http://your-server:9090`
7. Enable backups:
   ```bash
   chmod +x scripts/*.sh
   crontab -e
   ```
   Paste the line from `scripts/backup_cron_example.txt`
