# Phase 8 Windows Patch

This package replaces the frontend bundler with a no-build static admin UI.

## Why
Your Windows environment hit a native optional dependency bug around rolldown bindings. This patch removes that problem entirely.

## How to run
```bash
cd apps/admin_ui
npm run dev
```

Then open:
```text
http://localhost:5173
```

## Important
This still expects the backend to be running and available behind:
```text
/api
```
